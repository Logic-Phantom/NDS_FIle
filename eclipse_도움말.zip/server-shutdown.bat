@echo off
rem 현재 디렉토리 저장
setlocal
set "currentDir=%cd%"

rem ./plugins 경로로 이동
cd ./plugins

rem 파일을 찾고 첫 번째 일치하는 파일의 경로를 변수에 저장
for %%f in (org.eclipse.help.base_*.jar) do (
    set jarPath=%%~f
    goto :found
)

:found
rem 원래 경로로 복귀
cd "%currentDir%"

rem 확인된 Java 21 경로 적용
set "JAVA_CMD=C:\eclipse\jdk-21.0.12.1\bin\java.exe"

rem 찾은 파일 경로 출력 및 확인
if defined jarPath (
    echo Found: %jarPath%
    echo Using Java: %JAVA_CMD%
    
    rem 지정된 java 명령어 실행
    "%JAVA_CMD%" -classpath .\plugins\%jarPath% org.eclipse.help.standalone.Infocenter -command shutdown -eclipsehome .\
) else (
    echo No matching file found.
)

endlocal