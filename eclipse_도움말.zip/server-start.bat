@echo off
rem 현재 디렉토리 저장
setlocal
set "currentDir=%cd%"

rem ./plugins 경로로 이동
cd ./plugins

rem 파일을 찾고 첫 번째 일치하는 파일의 경로를 변수에 저장
for %%f in (org.eclipse.help.base_*.jar) do (
    set jarPath=%%~f
    goto :found
)

:found
rem 원래 경로로 복귀
cd "%currentDir%"

rem 아래 경로를 실제 가지고 계신 jdk_21의 java.exe 경로로 변경하세요.
set "JAVA_CMD=C:\eclipse\jdk-21.0.12.1\bin\java.exe"

rem 찾은 파일 경로 출력 및 확인
if defined jarPath (
    echo Found: %jarPath%
    echo Using Java: %JAVA_CMD%
    
    rem 지정한 Java 경로로 도움말 서버 실행
    "%JAVA_CMD%" -classpath .\plugins\%jarPath% org.eclipse.help.standalone.Infocenter -command start -port 8081 -eclipsehome .\
) else (
    echo No matching file found.
)

endlocal